// خادم بسيط بدون مكتبات خارجية — يشتغل على Replit وأي استضافة Node 18+
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const TOKEN = process.env.HUBSPOT_TOKEN || "";
const PW = process.env.APP_PASSWORD || "";
const SECRET = process.env.APP_SECRET || "change-me";
const SESSION = crypto.createHmac("sha256", SECRET).update("ok").digest("hex");
// حسابات أوروبا: بعض الحسابات تحتاج api.hubapi.com (يشتغل عالمياً). إن لزم غيّريه لـ api.hubapi.eu
const API = process.env.HUBSPOT_API_BASE || "https://api.hubapi.com";

function authed(req) {
  const c = req.headers.cookie || "";
  const m = c.match(/session=([^;]+)/);
  return m && m[1] === SESSION;
}
function readBody(req) {
  return new Promise(r => { let d = ""; req.on("data", c => d += c); req.on("end", () => { try { r(JSON.parse(d || "{}")); } catch (e) { r({}); } }); });
}
function send(res, code, obj) { res.writeHead(code, { "content-type": "application/json; charset=utf-8" }); res.end(JSON.stringify(obj)); }

const server = http.createServer(async (req, res) => {
  if (req.method === "POST" && req.url === "/api/login") {
    const b = await readBody(req);
    if (PW && b.password === PW) {
      res.setHeader("Set-Cookie", `session=${SESSION}; HttpOnly; Path=/; Max-Age=2592000; SameSite=Lax`);
      send(res, 200, { ok: true });
    } else send(res, 401, { ok: false });
    return;
  }
  if (req.method === "POST" && req.url === "/api/hubspot") {
    if (!authed(req)) return send(res, 401, { isError: true, content: [{ text: "unauthorized" }] });
    if (!TOKEN) return send(res, 500, { isError: true, content: [{ text: "HUBSPOT_TOKEN غير مضبوط في Secrets" }] });
    const { tool = "", args = {} } = await readBody(req);
    try {
      if (tool.endsWith("search_crm_objects")) {
        const payload = { filterGroups: args.filterGroups || [], properties: args.properties || [], limit: args.limit || 100 };
        if (args.offset) payload.after = String(args.offset);
        if (args.sorts) payload.sorts = args.sorts;
        const r = await fetch(API + "/crm/v3/objects/" + (args.objectType || "deals") + "/search", {
          method: "POST", headers: { authorization: "Bearer " + TOKEN, "content-type": "application/json" }, body: JSON.stringify(payload)
        });
        const j = await r.json();
        send(res, 200, r.ok ? { structuredContent: { results: j.results || [], total: j.total } } : { isError: true, content: [{ text: j.message || "HubSpot error" }] });
      } else if (tool.endsWith("search_properties")) {
        const r = await fetch(API + "/crm/v3/properties/" + (args.objectType || "deals"), { headers: { authorization: "Bearer " + TOKEN } });
        const j = await r.json();
        send(res, 200, r.ok ? { structuredContent: { results: (j.results || []).map(p => ({ name: p.name, label: p.label })) } } : { isError: true, content: [{ text: j.message || "HubSpot error" }] });
      } else send(res, 400, { isError: true, content: [{ text: "unknown tool" }] });
    } catch (e) { send(res, 200, { isError: true, content: [{ text: String(e && e.message || e) }] }); }
    return;
  }
  // ملف الواجهة
  fs.readFile(path.join(__dirname, "public", "index.html"), (e, data) => {
    if (e) { res.writeHead(404); res.end("not found"); }
    else { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end(data); }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, "0.0.0.0", () => console.log("noon-dashboard يعمل على المنفذ " + PORT));
